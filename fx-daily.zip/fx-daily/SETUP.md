# FX Daily Levels セットアップ手順書

所要時間：約15分（すべてブラウザ上の操作、Gitコマンド不要）

## 全体像

```
GitHub Actions（火〜土 8:30 JST頃に自動実行）
  ├─ Twelve Data → 7ペアの日足 → ADR20/ATR14/前日高安/Pivot/NY終値を計算
  ├─ Yahoo Finance → DXY・米10年債利回り・VIX
  └─ data/日付.json として履歴保存
         ↓
GitHub Pages がダッシュボード(index.html)を配信
  └─ 経済指標はinvesting.com公式ウィジェットをリアルタイム表示
```

---

## 手順1：GitHubアカウント作成（お持ちなら省略）

1. https://github.com/signup を開く
2. メールアドレス・パスワード・ユーザー名を登録

## 手順2：リポジトリ作成

1. ログイン後、右上の「+」→「New repository」
2. Repository name：`fx-daily`（任意の名前でOK）
3. **Public** を選択（※データは市場データのみ・APIキーは含まれないため公開で問題ありません。Publicの方がActionsの無料枠が無制限です）
4. 「Add a README file」に**チェックを入れる**（後のファイル追加が楽になります）
5. 「Create repository」

## 手順3：ファイルのアップロード

リポジトリ画面で「Add file」→「Upload files」を選び、以下を**フォルダ構造ごと**ドラッグ＆ドロップします：

- `fetch.js`
- `index.html`
- `.github` フォルダ（中に `workflows/daily.yml` が入っています）

> **注意（Windows）**：`.github`のようにドットで始まるフォルダはエクスプローラーで隠し扱いになることがあります。フォルダごとドラッグできない場合は、GitHub上で「Add file」→「Create new file」を選び、ファイル名欄に `.github/workflows/daily.yml` と入力（`/`を打つと自動でフォルダになります）し、daily.ymlの中身をコピペしてください。

アップロード後、下部の「Commit changes」を押して確定します。

## 手順4：APIキーをSecretsに登録

1. リポジトリの「Settings」タブ →左メニュー「Secrets and variables」→「Actions」
2. 「New repository secret」をクリック
3. Name：`TWELVE_DATA_API_KEY`（**この名前と完全一致させること**）
4. Secret：お持ちのTwelve DataのAPIキーを貼り付け
5. 「Add secret」

> Secretsに入れたキーは、リポジトリが公開でも第三者からは見えません。

## 手順5：GitHub Pagesを有効化

1. 「Settings」→左メニュー「Pages」
2. 「Source」を「Deploy from a branch」に
3. Branch：`main`、フォルダ：`/ (root)` を選択して「Save」
4. 数分後、`https://ユーザー名.github.io/fx-daily/` でダッシュボードが公開されます
   （URLはPages設定画面の上部に表示されます。これをブックマークしてください）

## 手順6：初回の手動実行（動作確認）

1. リポジトリの「Actions」タブを開く
2. 初回は「I understand my workflows, go ahead and enable them」を押す
3. 左の「Daily FX Data」→右上「Run workflow」→緑の「Run workflow」ボタン
4. 1〜2分で完了します。緑のチェック✅が付けば成功
5. リポジトリに `data/` フォルダとJSONファイルが増えていることを確認
6. ダッシュボードURLを開き、7ペアの数値が表示されればOK
   （Pagesへの反映に1〜2分かかることがあります。表示されない場合は少し待ってから再読み込み）

## 手順7：investing.comウィジェットの調整（任意）

デフォルトの埋め込み設定で言語やタイムゾーンが合わない場合：

1. https://jp.investing.com/webmaster-tools/economic-calendar を開く
2. タイムゾーン「(GMT +9:00) 東京」、重要度（★2〜3）、対象国（米国・日本・ユーロ圏・英国・オーストラリア）を選択
3. 利用条件に同意して埋め込みコード（`<iframe>...`）を生成・コピー
4. GitHub上で `index.html` を開き、鉛筆アイコン（Edit）をクリック
5. `▼ investing.com 公式ウィジェット ▼` というコメントの下にある `<iframe ...></iframe>` を丸ごと差し替えて「Commit changes」

---

## 日々の運用

- **何もしなくてOK**です。火〜土の朝8:30 JST頃に自動でデータが更新されます
- 朝9:00にブックマークしたURLを開くだけ
- 経済指標ウィジェットはリアルタイム更新（結果値も自動反映）

## 既知の制約・トラブル時

| 症状 | 原因と対処 |
|---|---|
| 朝9時にデータが前日のまま | GitHub Actionsのcronは混雑時に数十分遅延することがあります。Actionsタブから手動実行するか、少し待ってください |
| DXY/US10Y/VIXだけ「取得失敗」 | Yahoo Financeの非公式APIの仕様変更の可能性。ペアデータは影響を受けません。発生したら相談してください（FRED公式APIへの切替が可能） |
| 全ペア取得失敗 | Twelve DataのAPIキー無効・入力ミスの可能性。Secretsの値を確認（手順4） |
| 数値がTradingViewの表示と数pipsずれる | データフィード（ブローカー）の違いによる正常な誤差です |
| 月曜朝にデータがない | 仕様です（月曜朝時点の「前日」は日曜の不完全な足のため、実行は火〜土のみ） |

## 実行スケジュールを変更したい場合

`.github/workflows/daily.yml` の `cron: "30 23 * * 1-5"` を編集します。
時刻はUTC表記です（JST − 9時間）。例：毎日7:00 JSTなら `"0 22 * * *"`
